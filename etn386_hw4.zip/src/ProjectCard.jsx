import React from 'react';
import { Card, CardContent, Button } from '@mui/material';

function ProjectCard({ project, onJoinToggle }) {
  return (
    <Card
      sx={{
        margin: '1rem 0',
        border: '2px solid #ffc1cc',
        borderRadius: '12px'
      }}
    >
      <CardContent>
        <h2 style={{ color: '#f47c7c', marginBottom: '0.5rem' }}>
          {project.name}
        </h2>
        <p style={{ marginBottom: '1rem' }}>
          {project.joined
            ? 'You have joined this project.'
            : 'You are not joined yet.'}
        </p>
        <Button
          variant="contained"
          onClick={onJoinToggle}
          sx={{
            backgroundColor: project.joined ? '#ff99ac' : '#ffb3c1',
            '&:hover': {
              backgroundColor: project.joined ? '#ff748c' : '#ff9fb2'
            }
          }}
        >
          {project.joined ? 'Leave Project' : 'Join Project'}
        </Button>
      </CardContent>
    </Card>
  );
}

export default ProjectCard;
