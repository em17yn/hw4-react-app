import React from 'react';
import './App.css';       
import Projects from './Projects'; // parent component

function App() {
  return (
    <div className="App">
      <Projects />
    </div>
  );
}

export default App;
